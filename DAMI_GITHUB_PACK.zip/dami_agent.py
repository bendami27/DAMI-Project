# Agent DAMI
print("Agent DAMI actif — simulation d'automatisation.")