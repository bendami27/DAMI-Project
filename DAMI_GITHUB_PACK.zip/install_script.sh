#!/bin/bash
echo "Installation automatique DAMI (fictive ici)"
